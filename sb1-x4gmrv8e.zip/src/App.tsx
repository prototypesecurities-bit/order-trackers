import React, { useState, useEffect } from 'react';
import { Package, Search, User, LogOut, Plus, Edit, Download, Mail, Eye, Trash2, Filter, BarChart3, Truck, CheckCircle, Clock } from 'lucide-react';
import { Shipment, User as UserType, ShipmentStatus, ServiceType } from './types/shipment';
import { storageService } from './services/storage';
import { AWBGenerator } from './services/awbGenerator';

function App() {
  const [currentView, setCurrentView] = useState<'tracking' | 'login' | 'dashboard'>('tracking');
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);
  const [dashboardTab, setDashboardTab] = useState<'overview' | 'shipments' | 'add' | 'edit'>('overview');
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [filteredShipments, setFilteredShipments] = useState<Shipment[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<ShipmentStatus | 'all'>('all');

  // Tracking states
  const [trackingId, setTrackingId] = useState('');
  const [trackingResult, setTrackingResult] = useState<Shipment | null>(null);
  const [trackingError, setTrackingError] = useState('');
  const [isTracking, setIsTracking] = useState(false);

  // Login states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Form states
  const [formData, setFormData] = useState<Partial<Shipment>>({});

  useEffect(() => {
    const user = storageService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
      setCurrentView('dashboard');
      loadShipments(user);
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadShipments(currentUser);
    }
  }, [currentUser]);

  useEffect(() => {
    filterShipments();
  }, [shipments, searchTerm, statusFilter]);

  const loadShipments = (user: UserType) => {
    const userShipments = storageService.getShipmentsByUser(user.email);
    setShipments(userShipments);
  };

  const filterShipments = () => {
    let filtered = shipments;

    if (searchTerm) {
      filtered = filtered.filter(shipment =>
        shipment.trackingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        shipment.shipperName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        shipment.consigneeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        shipment.destination.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(shipment => shipment.status === statusFilter);
    }

    setFilteredShipments(filtered);
  };

  const handleTracking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingId.trim()) return;

    setIsTracking(true);
    setTrackingError('');
    setTrackingResult(null);

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const shipment = storageService.getShipmentByTrackingId(trackingId.trim());
    
    if (shipment) {
      setTrackingResult(shipment);
    } else {
      setTrackingError('No shipment found with this tracking ID');
    }

    setIsTracking(false);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = storageService.login(loginEmail, loginPassword);
    
    if (user) {
      setCurrentUser(user);
      setCurrentView('dashboard');
      loadShipments(user);
      setLoginEmail('');
      setLoginPassword('');
    } else {
      alert('Invalid credentials');
    }
  };

  const handleLogout = () => {
    storageService.logout();
    setCurrentUser(null);
    setCurrentView('tracking');
    setShipments([]);
    setDashboardTab('overview');
  };

  const handleAddShipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const newShipment = storageService.addShipment({
      ...formData as Omit<Shipment, 'id' | 'trackingId' | 'dateCreated'>,
      createdBy: currentUser.email
    });

    loadShipments(currentUser);
    setFormData({});
    setDashboardTab('shipments');
    alert(`Shipment created successfully! Tracking ID: ${newShipment.trackingId}`);
  };

  const handleUpdateShipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedShipment || !currentUser) return;

    storageService.updateShipment(selectedShipment.id, formData);
    loadShipments(currentUser);
    setSelectedShipment(null);
    setFormData({});
    setDashboardTab('shipments');
    alert('Shipment updated successfully!');
  };

  const handleDeleteShipment = (id: string) => {
    if (confirm('Are you sure you want to delete this shipment?')) {
      storageService.deleteShipment(id);
      if (currentUser) {
        loadShipments(currentUser);
      }
    }
  };

  const handleDownloadAWB = (shipment: Shipment) => {
    AWBGenerator.generateAWB(shipment);
  };

  const handleEmailAWB = async (shipment: Shipment) => {
    const email = prompt('Enter email address to send AWB:');
    if (email) {
      await AWBGenerator.emailAWB(shipment, email);
    }
  };

  const getStatusColor = (status: ShipmentStatus) => {
    const colors = {
      'picked-up': 'bg-blue-100 text-blue-800',
      'arrived-at-airport': 'bg-purple-100 text-purple-800',
      'in-customs': 'bg-yellow-100 text-yellow-800',
      'departed': 'bg-indigo-100 text-indigo-800',
      'in-transit': 'bg-orange-100 text-orange-800',
      'out-for-delivery': 'bg-green-100 text-green-800',
      'delivered': 'bg-emerald-100 text-emerald-800',
      'returned': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusIcon = (status: ShipmentStatus) => {
    switch (status) {
      case 'delivered': return <CheckCircle className="w-4 h-4" />;
      case 'in-transit': case 'out-for-delivery': return <Truck className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const stats = currentUser ? storageService.getShipmentStats(currentUser.email) : null;

  // Tracking Page
  if (currentView === 'tracking') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-4">
              <Package className="w-12 h-12 text-blue-600 mr-3" />
              <h1 className="text-4xl font-bold text-gray-800">Expert Courier</h1>
            </div>
            <p className="text-gray-600 text-lg">Fast • Reliable • Secure Shipping Solutions</p>
            <div className="mt-6">
              <button
                onClick={() => setCurrentView('login')}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center mx-auto"
              >
                <User className="w-4 h-4 mr-2" />
                Client Login
              </button>
            </div>
          </div>

          {/* Tracking Form */}
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Track Your Shipment</h2>
              
              <form onSubmit={handleTracking} className="mb-6">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={trackingId}
                      onChange={(e) => setTrackingId(e.target.value)}
                      placeholder="Enter Tracking ID (e.g., EC24012345678901)"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isTracking}
                    className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center"
                  >
                    {isTracking ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    ) : (
                      <>
                        <Search className="w-5 h-5 mr-2" />
                        Track
                      </>
                    )}
                  </button>
                </div>
              </form>

              <div className="text-sm text-gray-500 text-center">
                Try sample tracking IDs: <span className="font-mono bg-gray-100 px-2 py-1 rounded">EC24012345678901</span> or <span className="font-mono bg-gray-100 px-2 py-1 rounded">EC24012345678902</span>
              </div>
            </div>

            {/* Tracking Results */}
            {trackingResult && (
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-800">Shipment Details</h3>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${getStatusColor(trackingResult.status)}`}>
                    {getStatusIcon(trackingResult.status)}
                    <span className="ml-1">{trackingResult.status.replace('-', ' ').toUpperCase()}</span>
                  </span>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-3">Shipment Information</h4>
                    <div className="space-y-2 text-sm">
                      <div><span className="font-medium">Tracking ID:</span> {trackingResult.trackingId}</div>
                      <div><span className="font-medium">Service:</span> {trackingResult.serviceType.toUpperCase()}</div>
                      <div><span className="font-medium">Pieces:</span> {trackingResult.pieces}</div>
                      <div><span className="font-medium">Weight:</span> {trackingResult.weight} kg</div>
                      <div><span className="font-medium">Destination:</span> {trackingResult.destination}</div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-3">Delivery Information</h4>
                    <div className="space-y-2 text-sm">
                      <div><span className="font-medium">From:</span> {trackingResult.shipperName}</div>
                      <div><span className="font-medium">To:</span> {trackingResult.consigneeName}</div>
                      <div><span className="font-medium">Date Created:</span> {new Date(trackingResult.dateCreated).toLocaleDateString()}</div>
                      <div><span className="font-medium">Est. Delivery:</span> {new Date(trackingResult.estimatedDelivery).toLocaleDateString()}</div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 justify-center">
                  <button
                    onClick={() => handleDownloadAWB(trackingResult)}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download AWB
                  </button>
                </div>
              </div>
            )}

            {/* Tracking Error */}
            {trackingError && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-center">
                {trackingError}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Login Page
  if (currentView === 'login') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <Package className="w-12 h-12 text-blue-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800">Client Login</h2>
            <p className="text-gray-600">Access your shipment dashboard</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              Login
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setCurrentView('tracking')}
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              ← Back to Tracking
            </button>
          </div>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg text-sm">
            <p className="font-medium text-gray-700 mb-2">Demo Credentials:</p>
            <p><strong>Admin:</strong> admin@expertcourier.com</p>
            <p><strong>Client:</strong> client@expertcourier.com</p>
            <p className="text-gray-500 mt-1">Use any password</p>
          </div>
        </div>
      </div>
    );
  }

  // Dashboard
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Package className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-xl font-bold text-gray-800">Expert Courier Dashboard</h1>
                <p className="text-sm text-gray-600">Welcome, {currentUser?.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">{currentUser?.role === 'admin' ? 'Administrator' : 'Client Manager'}</span>
              <button
                onClick={handleLogout}
                className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
              >
                <LogOut className="w-4 h-4 mr-1" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'shipments', label: 'All Shipments', icon: Package },
            { id: 'add', label: 'Add Shipment', icon: Plus }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setDashboardTab(tab.id as any)}
              className={`flex items-center px-4 py-2 rounded-md transition-colors ${
                dashboardTab === tab.id
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <tab.icon className="w-4 h-4 mr-2" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {dashboardTab === 'overview' && stats && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Package className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Total Shipments</p>
                    <p className="text-2xl font-bold text-gray-800">{stats.total}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Delivered</p>
                    <p className="text-2xl font-bold text-gray-800">{stats.delivered}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Truck className="w-6 h-6 text-orange-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">In Transit</p>
                    <p className="text-2xl font-bold text-gray-800">{stats.inTransit}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-center">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Clock className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Pending</p>
                    <p className="text-2xl font-bold text-gray-800">{stats.pending}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Shipments</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Tracking ID</th>
                      <th className="text-left py-2">Consignee</th>
                      <th className="text-left py-2">Destination</th>
                      <th className="text-left py-2">Status</th>
                      <th className="text-left py-2">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {shipments.slice(0, 5).map(shipment => (
                      <tr key={shipment.id} className="border-b">
                        <td className="py-2 font-mono text-sm">{shipment.trackingId}</td>
                        <td className="py-2">{shipment.consigneeName}</td>
                        <td className="py-2">{shipment.destination}</td>
                        <td className="py-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(shipment.status)}`}>
                            {shipment.status.replace('-', ' ')}
                          </span>
                        </td>
                        <td className="py-2 text-sm text-gray-600">
                          {new Date(shipment.dateCreated).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* All Shipments Tab */}
        {dashboardTab === 'shipments' && (
          <div className="space-y-6">
            {/* Filters */}
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex-1 min-w-64">
                  <input
                    type="text"
                    placeholder="Search by tracking ID, shipper, consignee, or destination..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as ShipmentStatus | 'all')}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="all">All Status</option>
                    <option value="picked-up">Picked Up</option>
                    <option value="arrived-at-airport">Arrived at Airport</option>
                    <option value="in-customs">In Customs</option>
                    <option value="departed">Departed</option>
                    <option value="in-transit">In Transit</option>
                    <option value="out-for-delivery">Out for Delivery</option>
                    <option value="delivered">Delivered</option>
                    <option value="returned">Returned</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Shipments Table */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left py-3 px-4">Tracking ID</th>
                      <th className="text-left py-3 px-4">Shipper</th>
                      <th className="text-left py-3 px-4">Consignee</th>
                      <th className="text-left py-3 px-4">Destination</th>
                      <th className="text-left py-3 px-4">Status</th>
                      <th className="text-left py-3 px-4">Weight</th>
                      <th className="text-left py-3 px-4">Date</th>
                      <th className="text-left py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredShipments.map(shipment => (
                      <tr key={shipment.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4 font-mono text-sm">{shipment.trackingId}</td>
                        <td className="py-3 px-4">{shipment.shipperName}</td>
                        <td className="py-3 px-4">{shipment.consigneeName}</td>
                        <td className="py-3 px-4">{shipment.destination}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs flex items-center w-fit ${getStatusColor(shipment.status)}`}>
                            {getStatusIcon(shipment.status)}
                            <span className="ml-1">{shipment.status.replace('-', ' ')}</span>
                          </span>
                        </td>
                        <td className="py-3 px-4">{shipment.weight} kg</td>
                        <td className="py-3 px-4 text-sm text-gray-600">
                          {new Date(shipment.dateCreated).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => {
                                setSelectedShipment(shipment);
                                setFormData(shipment);
                                setDashboardTab('edit');
                              }}
                              className="p-1 text-blue-600 hover:text-blue-800 transition-colors"
                              title="Edit"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDownloadAWB(shipment)}
                              className="p-1 text-green-600 hover:text-green-800 transition-colors"
                              title="Download AWB"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleEmailAWB(shipment)}
                              className="p-1 text-purple-600 hover:text-purple-800 transition-colors"
                              title="Email AWB"
                            >
                              <Mail className="w-4 h-4" />
                            </button>
                            {currentUser?.role === 'admin' && (
                              <button
                                onClick={() => handleDeleteShipment(shipment.id)}
                                className="p-1 text-red-600 hover:text-red-800 transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {filteredShipments.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No shipments found matching your criteria.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Add Shipment Tab */}
        {dashboardTab === 'add' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-6">Add New Shipment</h3>
            
            <form onSubmit={handleAddShipment} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Shipper Information */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-700 border-b pb-2">Shipper Information</h4>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Shipper Name *</label>
                    <input
                      type="text"
                      value={formData.shipperName || ''}
                      onChange={(e) => setFormData({...formData, shipperName: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Shipper Address *</label>
                    <textarea
                      value={formData.shipperAddress || ''}
                      onChange={(e) => setFormData({...formData, shipperAddress: e.target.value})}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Shipper Phone *</label>
                    <input
                      type="tel"
                      value={formData.shipperPhone || ''}
                      onChange={(e) => setFormData({...formData, shipperPhone: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Shipper Email *</label>
                    <input
                      type="email"
                      value={formData.shipperEmail || ''}
                      onChange={(e) => setFormData({...formData, shipperEmail: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>

                {/* Consignee Information */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-700 border-b pb-2">Consignee Information</h4>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Consignee Name *</label>
                    <input
                      type="text"
                      value={formData.consigneeName || ''}
                      onChange={(e) => setFormData({...formData, consigneeName: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Consignee Address *</label>
                    <textarea
                      value={formData.consigneeAddress || ''}
                      onChange={(e) => setFormData({...formData, consigneeAddress: e.target.value})}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Consignee Phone *</label>
                    <input
                      type="tel"
                      value={formData.consigneePhone || ''}
                      onChange={(e) => setFormData({...formData, consigneePhone: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Consignee Email *</label>
                    <input
                      type="email"
                      value={formData.consigneeEmail || ''}
                      onChange={(e) => setFormData({...formData, consigneeEmail: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Shipment Details */}
              <div className="border-t pt-6">
                <h4 className="font-medium text-gray-700 mb-4">Shipment Details</h4>
                
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Number of Pieces *</label>
                    <input
                      type="number"
                      min="1"
                      value={formData.pieces || ''}
                      onChange={(e) => setFormData({...formData, pieces: parseInt(e.target.value)})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Weight (kg) *</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      value={formData.weight || ''}
                      onChange={(e) => setFormData({...formData, weight: parseFloat(e.target.value)})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service Type *</label>
                    <select
                      value={formData.serviceType || ''}
                      onChange={(e) => setFormData({...formData, serviceType: e.target.value as ServiceType})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    >
                      <option value="">Select Service</option>
                      <option value="standard">Standard Delivery</option>
                      <option value="express">Express Delivery</option>
                      <option value="overnight">Overnight Delivery</option>
                    </select>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Destination *</label>
                    <input
                      type="text"
                      value={formData.destination || ''}
                      onChange={(e) => setFormData({...formData, destination: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="City, State/Country"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Estimated Delivery *</label>
                    <input
                      type="date"
                      value={formData.estimatedDelivery || ''}
                      onChange={(e) => setFormData({...formData, estimatedDelivery: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>
                
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Initial Status *</label>
                  <select
                    value={formData.status || 'picked-up'}
                    onChange={(e) => setFormData({...formData, status: e.target.value as ShipmentStatus})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="picked-up">Picked Up</option>
                    <option value="arrived-at-airport">Arrived at Airport</option>
                    <option value="in-customs">In Customs</option>
                    <option value="departed">Departed</option>
                    <option value="in-transit">In Transit</option>
                    <option value="out-for-delivery">Out for Delivery</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </div>
                
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Notes (Optional)</label>
                  <textarea
                    value={formData.notes || ''}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Special handling instructions, fragile items, etc."
                  />
                </div>
              </div>

              <div className="flex justify-end gap-4 pt-6 border-t">
                <button
                  type="button"
                  onClick={() => {
                    setFormData({});
                    setDashboardTab('shipments');
                  }}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Shipment
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Edit Shipment Tab */}
        {dashboardTab === 'edit' && selectedShipment && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800">Edit Shipment: {selectedShipment.trackingId}</h3>
              <button
                onClick={() => {
                  setDashboardTab('shipments');
                  setSelectedShipment(null);
                  setFormData({});
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            
            <form onSubmit={handleUpdateShipment} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Current Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Current Status *</label>
                  <select
                    value={formData.status || selectedShipment.status}
                    onChange={(e) => setFormData({...formData, status: e.target.value as ShipmentStatus})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="picked-up">Picked Up</option>
                    <option value="arrived-at-airport">Arrived at Airport</option>
                    <option value="in-customs">In Customs</option>
                    <option value="departed">Departed</option>
                    <option value="in-transit">In Transit</option>
                    <option value="out-for-delivery">Out for Delivery</option>
                    <option value="delivered">Delivered</option>
                    <option value="returned">Returned</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Estimated Delivery</label>
                  <input
                    type="date"
                    value={formData.estimatedDelivery || selectedShipment.estimatedDelivery}
                    onChange={(e) => setFormData({...formData, estimatedDelivery: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                <textarea
                  value={formData.notes !== undefined ? formData.notes : (selectedShipment.notes || '')}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Update notes or add tracking information..."
                />
              </div>

              <div className="flex justify-between items-center pt-6 border-t">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleDownloadAWB(selectedShipment)}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download AWB
                  </button>
                  <button
                    type="button"
                    onClick={() => handleEmailAWB(selectedShipment)}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Email AWB
                  </button>
                </div>
                
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      setDashboardTab('shipments');
                      setSelectedShipment(null);
                      setFormData({});
                    }}
                    className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Update Shipment
                  </button>
                </div>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;