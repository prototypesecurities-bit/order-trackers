export interface Shipment {
  id: string;
  trackingNumber: string;
  shipperName: string;
  shipperAddress: string;
  shipperPhone: string;
  shipperEmail: string;
  shipperCity: string;
  shipperState: string;
  shipperZip: string;
  consigneeName: string;
  consigneeAddress: string;
  consigneePhone: string;
  consigneeEmail: string;
  consigneeCity: string;
  consigneeState: string;
  consigneeZip: string;
  pieces: number;
  weight: number;
  dimensions: string;
  destination: string;
  origin: string;
  status: ShipmentStatus;
  serviceType: ServiceType;
  dateCreated: string;
  estimatedDelivery: string;
  actualDelivery?: string;
  createdBy: string;
  notes?: string;
  declaredValue?: number;
  contentDescription: string;
  specialInstructions?: string;
}

export type ShipmentStatus = 
  | 'in-process'
  | 'in-transit'
  | 'delivered'
  | 'cancelled';

export type ServiceType = 
  | 'standard'
  | 'express'
  | 'overnight'
  | 'international';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin';
  company: string;
}

export interface TrackingResult {
  success: boolean;
  shipment?: Shipment;
  error?: string;
}

export interface ShipmentStats {
  total: number;
  inProcess: number;
  inTransit: number;
  delivered: number;
  cancelled: number;
}