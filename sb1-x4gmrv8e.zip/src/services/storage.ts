import { Shipment, User } from '../types/shipment';

// Local Storage Service for Demo (In production, this would be replaced with API calls)
class StorageService {
  private readonly SHIPMENTS_KEY = 'expert_courier_shipments';
  private readonly USERS_KEY = 'expert_courier_users';
  private readonly CURRENT_USER_KEY = 'expert_courier_current_user';

  // Initialize with demo data
  constructor() {
    this.initializeDemoData();
  }

  private initializeDemoData() {
    if (!localStorage.getItem(this.SHIPMENTS_KEY)) {
      const demoShipments: Shipment[] = [
        {
          id: '1',
          trackingId: 'EC24012345678901',
          shipperName: 'ABC Electronics Ltd',
          shipperAddress: '123 Business Park, New York, NY 10001',
          shipperPhone: '+1-555-0123',
          shipperEmail: 'shipping@abcelectronics.com',
          consigneeName: 'John Smith',
          consigneeAddress: '456 Oak Street, Los Angeles, CA 90210',
          consigneePhone: '+1-555-0456',
          consigneeEmail: 'john.smith@email.com',
          pieces: 2,
          weight: 5.5,
          destination: 'Los Angeles, CA',
          status: 'in-transit',
          serviceType: 'express',
          dateCreated: '2024-01-15',
          estimatedDelivery: '2024-01-18',
          createdBy: 'client@expertcourier.com',
          notes: 'Handle with care - Electronics'
        },
        {
          id: '2',
          trackingId: 'EC24012345678902',
          shipperName: 'Fashion Forward Inc',
          shipperAddress: '789 Fashion Ave, Miami, FL 33101',
          shipperPhone: '+1-555-0789',
          shipperEmail: 'orders@fashionforward.com',
          consigneeName: 'Sarah Johnson',
          consigneeAddress: '321 Pine Road, Chicago, IL 60601',
          consigneePhone: '+1-555-0321',
          consigneeEmail: 'sarah.j@email.com',
          pieces: 1,
          weight: 2.0,
          destination: 'Chicago, IL',
          status: 'delivered',
          serviceType: 'standard',
          dateCreated: '2024-01-10',
          estimatedDelivery: '2024-01-15',
          createdBy: 'client@expertcourier.com'
        }
      ];
      localStorage.setItem(this.SHIPMENTS_KEY, JSON.stringify(demoShipments));
    }

    if (!localStorage.getItem(this.USERS_KEY)) {
      const demoUsers: User[] = [
        {
          id: '1',
          email: 'admin@expertcourier.com',
          name: 'Admin User',
          role: 'admin',
          company: 'Expert Courier'
        },
        {
          id: '2',
          email: 'client@expertcourier.com',
          name: 'Client Manager',
          role: 'client',
          company: 'ABC Electronics Ltd'
        }
      ];
      localStorage.setItem(this.USERS_KEY, JSON.stringify(demoUsers));
    }
  }

  // Shipment operations
  getAllShipments(): Shipment[] {
    const shipments = localStorage.getItem(this.SHIPMENTS_KEY);
    return shipments ? JSON.parse(shipments) : [];
  }

  getShipmentsByUser(userEmail: string): Shipment[] {
    const allShipments = this.getAllShipments();
    const currentUser = this.getCurrentUser();
    
    if (currentUser?.role === 'admin') {
      return allShipments;
    }
    
    return allShipments.filter(shipment => shipment.createdBy === userEmail);
  }

  getShipmentByTrackingId(trackingId: string): Shipment | null {
    const shipments = this.getAllShipments();
    return shipments.find(shipment => shipment.trackingId === trackingId) || null;
  }

  addShipment(shipment: Omit<Shipment, 'id' | 'trackingId' | 'dateCreated'>): Shipment {
    const shipments = this.getAllShipments();
    const newShipment: Shipment = {
      ...shipment,
      id: Date.now().toString(),
      trackingId: this.generateTrackingId(),
      dateCreated: new Date().toISOString().split('T')[0]
    };
    
    shipments.push(newShipment);
    localStorage.setItem(this.SHIPMENTS_KEY, JSON.stringify(shipments));
    return newShipment;
  }

  updateShipment(id: string, updates: Partial<Shipment>): Shipment | null {
    const shipments = this.getAllShipments();
    const index = shipments.findIndex(shipment => shipment.id === id);
    
    if (index === -1) return null;
    
    shipments[index] = { ...shipments[index], ...updates };
    localStorage.setItem(this.SHIPMENTS_KEY, JSON.stringify(shipments));
    return shipments[index];
  }

  deleteShipment(id: string): boolean {
    const shipments = this.getAllShipments();
    const filteredShipments = shipments.filter(shipment => shipment.id !== id);
    
    if (filteredShipments.length === shipments.length) return false;
    
    localStorage.setItem(this.SHIPMENTS_KEY, JSON.stringify(filteredShipments));
    return true;
  }

  // User operations
  login(email: string, password: string): User | null {
    const users = this.getUsers();
    const user = users.find(u => u.email === email);
    
    if (user) {
      localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(user));
      return user;
    }
    
    return null;
  }

  logout(): void {
    localStorage.removeItem(this.CURRENT_USER_KEY);
  }

  getCurrentUser(): User | null {
    const user = localStorage.getItem(this.CURRENT_USER_KEY);
    return user ? JSON.parse(user) : null;
  }

  private getUsers(): User[] {
    const users = localStorage.getItem(this.USERS_KEY);
    return users ? JSON.parse(users) : [];
  }

  private generateTrackingId(): string {
    const prefix = 'EC';
    const year = new Date().getFullYear().toString().slice(-2);
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `${prefix}${year}${timestamp}${random}`;
  }

  // Statistics
  getShipmentStats(userEmail?: string): {
    total: number;
    delivered: number;
    inTransit: number;
    pending: number;
  } {
    const shipments = userEmail ? this.getShipmentsByUser(userEmail) : this.getAllShipments();
    
    return {
      total: shipments.length,
      delivered: shipments.filter(s => s.status === 'delivered').length,
      inTransit: shipments.filter(s => ['in-transit', 'departed', 'out-for-delivery'].includes(s.status)).length,
      pending: shipments.filter(s => ['picked-up', 'arrived-at-airport', 'in-customs'].includes(s.status)).length
    };
  }
}

export const storageService = new StorageService();