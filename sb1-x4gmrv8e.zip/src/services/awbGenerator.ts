import { Shipment } from '../types/shipment';

export class AWBGenerator {
  static generateAWB(shipment: Shipment): void {
    // Create AWB content
    const awbContent = this.createAWBContent(shipment);
    
    // Create and download PDF
    this.downloadAWB(awbContent, shipment.trackingId);
  }

  static async emailAWB(shipment: Shipment, recipientEmail: string): Promise<boolean> {
    try {
      // In a real implementation, this would call your email service
      console.log(`Sending AWB for ${shipment.trackingId} to ${recipientEmail}`);
      
      // Simulate email sending
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Show success message
      alert(`AWB has been sent to ${recipientEmail}`);
      return true;
    } catch (error) {
      console.error('Failed to send AWB email:', error);
      return false;
    }
  }

  private static createAWBContent(shipment: Shipment): string {
    const currentDate = new Date().toLocaleDateString();
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Air Way Bill - ${shipment.trackingId}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: white;
            color: #333;
        }
        .awb-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #1e40af;
            padding: 0;
        }
        .awb-header {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }
        .company-logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .company-tagline {
            font-size: 14px;
            opacity: 0.9;
        }
        .awb-title {
            font-size: 24px;
            font-weight: bold;
            margin: 15px 0 5px 0;
        }
        .tracking-id {
            font-size: 18px;
            background: rgba(255,255,255,0.2);
            padding: 8px 16px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
        .awb-body {
            padding: 30px;
        }
        .info-section {
            margin-bottom: 25px;
        }
        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #1e40af;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #e5e7eb;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 25px;
        }
        .info-box {
            border: 1px solid #d1d5db;
            border-radius: 8px;
            padding: 15px;
            background: #f9fafb;
        }
        .info-row {
            margin-bottom: 8px;
        }
        .info-label {
            font-weight: bold;
            color: #374151;
            display: inline-block;
            width: 120px;
        }
        .info-value {
            color: #6b7280;
        }
        .shipment-details {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        .detail-item {
            text-align: center;
            padding: 10px;
            background: white;
            border-radius: 5px;
            border: 1px solid #dbeafe;
        }
        .detail-label {
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .detail-value {
            font-size: 16px;
            font-weight: bold;
            color: #1e40af;
        }
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            background: #10b981;
            color: white;
        }
        .qr-section {
            text-align: center;
            margin: 25px 0;
            padding: 20px;
            background: #f3f4f6;
            border-radius: 8px;
        }
        .qr-code {
            width: 120px;
            height: 120px;
            margin: 0 auto 10px;
            border: 2px solid #d1d5db;
            border-radius: 8px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            color: #6b7280;
        }
        .awb-footer {
            background: #f9fafb;
            padding: 20px;
            border-top: 1px solid #e5e7eb;
            text-align: center;
            font-size: 12px;
            color: #6b7280;
        }
        .footer-info {
            margin-bottom: 10px;
        }
        .terms {
            font-size: 10px;
            line-height: 1.4;
            margin-top: 15px;
            text-align: left;
        }
        @media print {
            body { margin: 0; padding: 10px; }
            .awb-container { border: 1px solid #000; }
        }
    </style>
</head>
<body>
    <div class="awb-container">
        <div class="awb-header">
            <div class="company-logo">EXPERT COURIER</div>
            <div class="company-tagline">Fast • Reliable • Secure Shipping Solutions</div>
            <div class="awb-title">AIR WAY BILL</div>
            <div class="tracking-id">Tracking ID: ${shipment.trackingId}</div>
        </div>
        
        <div class="awb-body">
            <div class="info-grid">
                <div class="info-box">
                    <div class="section-title">SHIPPER INFORMATION</div>
                    <div class="info-row">
                        <span class="info-label">Name:</span>
                        <span class="info-value">${shipment.shipperName}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Address:</span>
                        <span class="info-value">${shipment.shipperAddress}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone:</span>
                        <span class="info-value">${shipment.shipperPhone}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email:</span>
                        <span class="info-value">${shipment.shipperEmail}</span>
                    </div>
                </div>
                
                <div class="info-box">
                    <div class="section-title">CONSIGNEE INFORMATION</div>
                    <div class="info-row">
                        <span class="info-label">Name:</span>
                        <span class="info-value">${shipment.consigneeName}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Address:</span>
                        <span class="info-value">${shipment.consigneeAddress}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone:</span>
                        <span class="info-value">${shipment.consigneePhone}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email:</span>
                        <span class="info-value">${shipment.consigneeEmail}</span>
                    </div>
                </div>
            </div>
            
            <div class="shipment-details">
                <div class="section-title">SHIPMENT DETAILS</div>
                <div class="details-grid">
                    <div class="detail-item">
                        <div class="detail-label">Pieces</div>
                        <div class="detail-value">${shipment.pieces}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Weight</div>
                        <div class="detail-value">${shipment.weight} kg</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Service</div>
                        <div class="detail-value">${shipment.serviceType.toUpperCase()}</div>
                    </div>
                </div>
                
                <div style="margin-top: 15px;">
                    <div class="info-row">
                        <span class="info-label">Destination:</span>
                        <span class="info-value">${shipment.destination}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Status:</span>
                        <span class="status-badge">${shipment.status.replace('-', ' ')}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Date Created:</span>
                        <span class="info-value">${new Date(shipment.dateCreated).toLocaleDateString()}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Est. Delivery:</span>
                        <span class="info-value">${new Date(shipment.estimatedDelivery).toLocaleDateString()}</span>
                    </div>
                    ${shipment.notes ? `
                    <div class="info-row">
                        <span class="info-label">Notes:</span>
                        <span class="info-value">${shipment.notes}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
            
            <div class="qr-section">
                <div class="qr-code">
                    QR Code<br>
                    ${shipment.trackingId}
                </div>
                <div style="font-size: 12px; color: #6b7280;">
                    Scan to track this shipment online
                </div>
            </div>
        </div>
        
        <div class="awb-footer">
            <div class="footer-info">
                <strong>Expert Courier Services</strong><br>
                📧 info@expertcourier.com | 📞 +1-800-COURIER | 🌐 www.expertcourier.com
            </div>
            <div class="footer-info">
                Generated on: ${currentDate} | Document ID: AWB-${shipment.trackingId}
            </div>
            
            <div class="terms">
                <strong>Terms & Conditions:</strong> This Air Way Bill is subject to Expert Courier's standard terms and conditions. 
                The shipper certifies that the particulars on the face hereof are correct and that the shipment does not contain 
                any dangerous goods. Expert Courier's liability is limited as per our terms of service. For claims, contact us within 
                30 days of delivery. This document serves as proof of shipment and delivery authorization.
            </div>
        </div>
    </div>
</body>
</html>`;
  }

  private static downloadAWB(content: string, trackingId: string): void {
    try {
      // Create a downloadable HTML file
      const blob = new Blob([content], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `AWB-${trackingId}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

    } catch (error) {
      console.error('Error generating AWB:', error);
      alert('Error generating AWB. Please try again.');
    }
  }
}